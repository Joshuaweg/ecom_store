"""
Package for ecom_store.
"""
