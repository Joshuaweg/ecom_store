from django.shortcuts import render

# Create your views here.

def email_confirmation(request):  # Rename is necessary
   
    pass

    #return render(request, '') # html template goes here
